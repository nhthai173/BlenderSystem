/// <reference path="/Users/thainguyen/.vscode/extensions/undefined_publisher.wincc-custom-web-controls-0.0.1/typings/webcc.d.ts" />

/* ===================== Global Type ===================== */

class DataSet {
    constructor(data = []) {
        this.data = data || []
    }
    set(data) {
        if (!Array.isArray(data)) {
            console.error('Data must be an array');
            return;
        }
        this.data = data.map(item => {
            if (typeof item === 'object' && item.value !== undefined && item.text !== undefined) {
                return item;
            } else if (typeof item === 'string') {
                return { value: item, text: item };
            } else {
                console.error('Invalid item format. Each item must be an object with "value" and "text" properties or a string.');
                return null;
            }
        }).filter(item => item !== null);
    }
    add(item) {
        if (this.has(item)) {
            return;
        }
        this.data.push(item);
    }
    delete(item) {
        let index = -1;
        if (typeof item === 'object') {
            index = this.data.findIndex(existingItem => existingItem.value === item.value);
        } else {
            index = this.data.findIndex(existingItem => existingItem.value === item);
        }
        if (index > -1) {
            this.data.splice(index, 1);
        }
    }
    clear() {
        this.data = [];
    }
    has(item) {
        if (typeof item === 'object') {
            return this.data.some(existingItem => existingItem.value == item.value);
        } else {
            return this.data.some(existingItem => existingItem.value == item);
        }
    }
    hasAll(items) {
        if (!Array.isArray(items)) {
            console.error('Items must be an array');
            return false;
        }
        return items.every(item => this.has(item));
    }
    getAll() {
        return this.data;
    }
}


/* ===================== Select List ===================== */

let $container = null;
let $searchContainer = null;
let $searchInput = null;
let $listElement = null;
let $clearIcon = null;

const CONFIG = {
    allowMultiSelect: true,
    allowSearch: true,
    selectAllText: 'Select All',
    callbackFn: null,
    setProperty: function (key, value) {
        if (key && value !== undefined && CONFIG.hasOwnProperty(key)) {
            CONFIG[key] = value;
        }
    },
    setProperties: function (properties) {
        if (!properties || !Object.keys(properties).length) return;
        for (const key in properties) {
            CONFIG.setProperty(key, properties[key]);
        }
    }
}

const SelectList = {
    data: [], // raw data
    filteredData: [], // show data
    searchData: [], // data for search
    selectedItems: new DataSet(),
}

const LISTENER = {
    onSearchInput: function (e) {
        searchTerm = toRawText(e.target.value);
        if (searchTerm === '') {
            clearSearch();
        } else {
            SelectList.filteredData = SelectList.searchData
                .filter(item => item.query.includes(searchTerm));
            $clearIcon.classList.add('active');
            render(SelectList.filteredData.length > 1);
        }
    },
    onItemSelect: function (e) {
        if (!e.target.type === 'checkbox') return
        const itemChecked = e.target.checked;
        const listItem = e.target.closest('.list-item');
        const itemValue = listItem.dataset.value;
        const itemText = listItem.querySelector('label').textContent.trim();

        if (itemValue === 'SELECT_ALL') {
            if (itemChecked) {
                selectAll();
            } else {
                clearSelection()
            }
            onSelectionChange()
            return
        }

        if (CONFIG.allowMultiSelect) {
            // Multi-select behavior
            if (itemChecked) {
                SelectList.selectedItems.add({ value: itemValue, text: itemText });
                listItem.classList.add('selected');
            } else {
                SelectList.selectedItems.delete(itemValue);
                listItem.classList.remove('selected');
            }
            if (SelectList.filteredData.length > 1) {
                render();
            }
        } else {
            // Single-select behavior
            if (itemChecked) {
                // Clear all other selections
                SelectList.selectedItems.clear();
                document.querySelectorAll('.list-item').forEach(item => {
                    item.classList.remove('selected');
                    item.querySelector('input[type="checkbox"]').checked = false;
                });

                // Select current item
                SelectList.selectedItems.add({ value: itemValue, text: itemText });
                listItem.classList.add('selected');
                e.target.checked = true;
            } else {
                SelectList.selectedItems.delete(itemValue);
                listItem.classList.remove('selected');
            }
        }
        onSelectionChange();
    }
}

function configUI({
    allowMultiSelect,
    allowSearch,
    selectAllText } = {}) {
    const _get = (a, b) => a !== undefined ? a : b;
    CONFIG.allowMultiSelect = _get(allowMultiSelect, CONFIG.allowMultiSelect);
    CONFIG.allowSearch = _get(allowSearch, CONFIG.allowSearch);
    CONFIG.selectAllText = _get(selectAllText, CONFIG.selectAllText);

    if (!CONFIG.allowSearch) {
        $searchContainer.style.display = 'none';
        $listElement.style.height = 'calc(100vh - 2*var(--body-padding))';
    } else {
        $searchContainer.style.display = 'block';
        const searchHeight = parseFloat(getComputedStyle($searchContainer).height) || 0;
        $listElement.style.height = `calc(100vh - ${searchHeight}px - 2*var(--body-padding))`;
    }
    if (!CONFIG.allowMultiSelect) {
        $container.classList.add('single-select');
    } else {
        $container.classList.remove('single-select');
    }
}

function init() {
    $container = document.querySelector('.select-list');
    if (!$container) {
        console.error('Select list container not found');
        return;
    }
    $searchContainer = $container.querySelector('.search');
    $searchInput = $container.querySelector('.search input');
    $listElement = $container.querySelector('.list-content');
    $clearIcon = $container.querySelector('.clear-icon');
    configUI()

    // Search functionality
    $searchInput.addEventListener('input', LISTENER.onSearchInput);
    $clearIcon.addEventListener('click', clearSearch);

    // Item selection
    $listElement.addEventListener('change', LISTENER.onItemSelect);

    render();
}

function toRawText(str) {
    if (!str) return ''
    str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
    str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
    str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
    str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
    str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
    str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
    str = str.replace(/đ/g, "d");
    str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
    str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
    str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
    str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
    str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
    str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
    str = str.replace(/Đ/g, "D");
    str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
    str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
    str = str.toLowerCase()
    str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;\|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, "");
    str = str.trim();
    str = str.replace(/\s+/g, "");
    return str;
}

function updateData(newData) {
    if (!Array.isArray(newData) || !newData.length) {
        console.error('Data must be an array');
        return;
    }
    if (!newData[0] || !newData[0].text || !newData[0].value) {
        console.error('Data items must have text and value properties');
        return;
    }
    SelectList.data = newData;
    SelectList.filteredData = [...newData];
    SelectList.searchData = newData.map(item => {
        return {
            query: toRawText(item.text),
            text: item.text,
            value: item.value
        }
    });
}

function clearSearch() {
    $searchInput.value = '';
    SelectList.filteredData = [...SelectList.data];
    $clearIcon.classList.remove('active');
    render();
}

function clearSelection() {
    SelectList.selectedItems.clear();
    render();
}

function selectAll() {
    if (!CONFIG.allowMultiSelect) {
        console.warn('selectAll() is not available in single-select mode');
        return;
    }

    SelectList.selectedItems.set(SelectList.filteredData);
    render();
}

// Event callback - override this method
function onSelectionChange() {
    const selectedItems = SelectList.selectedItems.getAll();
    if (CONFIG.callbackFn && typeof CONFIG.callbackFn == 'function') {
        CONFIG.callbackFn(selectedItems);
    }

    console.table(selectedItems);
    // Notify WebCC about the selection change
    WebCC.Events.fire('onSelectionChange', JSON.stringify(selectedItems));
}

function defaultView() {
    $searchInput.value = '';
    $searchInput.dispatchEvent(new Event('input'));
}

function render(showSelectAll = true) {
    $listElement.innerHTML = '';

    if (CONFIG.allowMultiSelect) {
        const allSelected = SelectList.filteredData.length > 0 &&
            SelectList.selectedItems.hasAll(SelectList.filteredData);
        const indeterminate = SelectList.selectedItems.getAll().length > 0 && !allSelected
        if (showSelectAll) {
            const selectAllItem = document.createElement('li');
            selectAllItem.className = 'list-item select-all-item' + ((allSelected || indeterminate) ? ' selected' : '');
            selectAllItem.dataset.value = 'SELECT_ALL';
            selectAllItem.innerHTML = `
                    <label class="checkbox ${indeterminate ? 'indeterminate' : ''}">${CONFIG.selectAllText}
                        <input type="checkbox" ${allSelected ? 'checked' : ''}>
                        <span class="checkmark"></span>
                    </label>
                `;
            $listElement.appendChild(selectAllItem);
        }
    }

    SelectList.filteredData.forEach((item, index) => {
        const listItem = document.createElement('li');
        listItem.className = 'list-item';
        listItem.dataset.value = item.value;

        const isSelected = SelectList.selectedItems.has(item.value);

        // Use radio button for single select, checkbox for multi-select
        const inputType = CONFIG.allowMultiSelect ? 'checkbox' : 'checkbox';

        listItem.innerHTML = `
                <label class="checkbox">${item.text}
                    <input type="${inputType}" ${isSelected ? 'checked' : ''}>
                    <span class="checkmark"></span>
                </label>
            `;

        if (isSelected) {
            listItem.classList.add('selected');
        }

        $listElement.appendChild(listItem);
    });
}




/* ===================== Main ===================== */

const SampleData = [
    {
        text: "Item 1",
        value: "Item 1"
    },
    {
        text: "Item 2",
        value: "Item 2"
    },
    {
        text: "Item 3",
        value: "Item 3"
    },
    {
        text: "Item 4",
        value: "Item 4"
    }
]

// let objectVar = null

// CONFIG.setProperties({
//     allowMultiSelect: true,
//     allowSearch: true,
//     selectAllText: "Select All"
// });
// updateData(SampleData);
// init()

// printPackageInfo()


////////////////////////////////////////////
// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)

WebCC.start(
    // callback function; occurs when the connection is done or failed. 
    // "result" is a boolean defining if the connection was successfull or not.
    function (result) {
        if (result) {
            if (WebCC.isDesignMode) {
                // Sample data
                try {
                    if (!WebCC.Properties.DataJSONString) {
                        WebCC.Properties.DataJSONString = JSON.stringify(SampleData);
                    }
                } catch (e) { }
            }

            // init select list
            let data = [];
            try {
                data = JSON.parse(WebCC.Properties.DataJSONString);
                updateData(data);
            } catch (e) { }
            CONFIG.setProperties({
                allowMultiSelect: WebCC.Properties.AllowMultiSelect,
                allowSearch: WebCC.Properties.AllowSearch,
                selectAllText: WebCC.Properties.SelectAllText
            })
            init();

            // Get css properties
            getCssProperties();

            // Set current values when CWC shows up
            for (const key in WebCC.Properties) {
                setProperty({ key, value: WebCC.Properties[key] });
            }

            // Subscribe for future value changes
            WebCC.onPropertyChanged.subscribe(setProperty);
        }
        else {
            console.log('connection failed');
        }
    },
    // contract (same as manifest.json)
    {
        // Methods
        methods: {
            defaultView: () => {
                defaultView();
            }
        },
        // Events
        events: ["onSelectionChange"],
        // Properties
        properties: {
            AllowSearch: true,
            AllowMultiSelect: true,
            SelectAllText: "Select All",
            DataJSONString: "",
            "FontSize": 18,
            "BgColor": 4293651952,
            "AlterBgColor": 4291874253,
            "TextColor": 4287006342,
            "AlterTextColor": 4291940822,
            "CheckColor": 4292664540,
            "BodyPadding": 10,
            "ContentPadding": 5,
            "BorderRadius": 20
        }
    },
    // placeholder to include additional Unified dependencies (not used in this example)
    [],
    // connection timeout
    10000
);

function getJSONValues(keys, data) {
    if (!keys || !Array.isArray(keys)) return null;
    if (!data || !Object.keys(data)) return
    let obj = {};
    for (const key of keys) {
        obj[key] = data[key];
    }
    return obj;
}

function setProperty(data) {
    const { key, value } = data;
    if (Object.keys(CssProperties).includes(key)) {
        try {
            const prop = CssProperties[key];
            switch (prop.type) {
                case "color":
                    setRootProperty(key, toColor(value));
                    break;
                case "size":
                    setRootProperty(key, value + 'px');
                    break;
                case "number": case "raw":
                    setRootProperty(key, value);
                    break;
            }
        } catch (e) { }
    } else {
        if (WebCC.Properties[key] !== undefined) {
            WebCC.Properties[key] = value;
        }

        let d = null;
        switch (key) {
            case "AllowMultiSelect":
                objectVar.setMultiSelect(value);
                objectVar.render();
                break;
            case "AllowSearch":
                objectVar.setSearch(value);
                objectVar.render();
                break;
            case "SelectAllText":
                objectVar.selectAllText = value;
                objectVar.render();
                break;
            case "DataJSONString":
                try {
                    d = JSON.parse(value);
                    if (Array.isArray(d)) {
                        objectVar.updateData(d);
                        objectVar.render();
                    } else {
                        console.error('Data must be an array');
                    }
                } catch (e) {
                    console.error('Invalid JSON data:', e);
                }
                break;
        }
    }
}