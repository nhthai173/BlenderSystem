var SampleArrayData = [];
var SampleColumnStyle = [];
var tableConfig_ = null;
var columnStyle_ = null;
var tableData_ = null;
var $table = null;


// For debuging from live server
// var WebCC = { Properties: {} }
// WebCC.Properties.ColumnStyleString = `[{"title":"Event", "field":"name", "width":150},{"title":"Time", "field":"salary"}]`;
// WebCC.Properties.TableDataString = `[{"name":"Filling source 2","salary":"09:06:18"},{"name":"Filling source 1","salary":"09:01:54"},{"name":"Start","salary":"09:01:33"},{"name":"Start 2","salary":"09:01:33"},{"name":"Start 3","salary":"09:01:33"}]`;
// WebCC.Properties.TableConfigString = `{"pagination":"local","paginationSize":3}`
// setProperty({ key: "TableConfigString", value: WebCC.Properties.TableConfigString });
// setProperty({ key: "ColumnStyleString", value: WebCC.Properties.ColumnStyleString });
// setProperty({ key: "TableDataString", value: WebCC.Properties.TableDataString });

// setProperty({ key: 'FontSize', value: 18 });
// setProperty({ key: 'RowHeight', value: 28 });

// printPackageInfo()





////////////////////////////////////////////
// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)

WebCC.start(
	// callback function; occurs when the connection is done or failed. 
	// "result" is a boolean defining if the connection was successfull or not.
	function (result) {
		if (result) {
			SampleArrayData = JSON.parse("[{\"name\":\"Donald\",\"salary\":\"2000\"},{\"name\":\"Mickey\",\"salary\":\"2100\"}]");
			SampleColumnStyle = JSON.parse("[{\"title\":\"Name\", \"field\":\"name\", \"sorter\":\"string\", \"width\":150},{\"title\":\"Salary\", \"field\":\"salary\", \"sorter\":\"number\", \"hozAlign\":\"left\"}]");

			if (WebCC.isDesignMode) {
				// Sample data
				try {
					if (!WebCC.Properties.TableDataString) {
						WebCC.Properties.TableDataString = JSON.stringify(SampleArrayData);
					}
					if (!WebCC.Properties.ColumnStyleString) {
						WebCC.Properties.ColumnStyleString = JSON.stringify(SampleColumnStyle);
					}
				} catch (e) { }
			}

			getCssProperties();

			// Set current values when CWC shows up
			for (const key in WebCC.Properties) {
				setProperty({ key, value: WebCC.Properties[key] });	
			}

			// Subscribe for future value changes
			WebCC.onPropertyChanged.subscribe(setProperty);
		}
		else {
			console.log('connection failed');
		}
	},
	// contract (same as manifest.json)
	{
		// Methods
		methods: {},
		// Events
		events: [],
		// Properties
		properties: {
			TableDataString: "",
			ColumnStyleString: "",
			TableConfigString: "",
			"BorderWidth": 1,
			"BorderColor": 4288256409,
			"BackgroundColor": 4287137928,
			"FontSize": 18,
			"FooterActiveColor": 4282412012,
			"RowHeight": 28
		}
	},
	// placeholder to include additional Unified dependencies (not used in this example)
	[],
	// connection timeout
	10000
);

function setProperty(data) {
	const { key, value } = data;
	if (Object.keys(CssProperties).includes(key)) {
		try {
			const prop = CssProperties[key];
			switch (prop.type) {
				case "color":
					setRootProperty(key, toColor(value));
					break;
				case "size":
					setRootProperty(key, value + 'px');
					break;
				case "number": case "raw":
					setRootProperty(key, value);
					break;
			}
		} catch (e) { }
	} else {
		switch (key) {
			case "ColumnStyleString":
				try {
					columnStyle_ = JSON.parse(value);
					WebCC.Properties.ColumnStyleString = value;
					drawTable();
				} catch (e) { }
				break;
			case "TableDataString":
				try {
					tableData_ = JSON.parse(value);
					WebCC.Properties.TableDataString = value;
					drawTable();
				} catch (e) { }
				break;
			case "TableConfigString":
				try {
					tableConfig_ = JSON.parse(value);
					WebCC.Properties.TableConfigString = value;
					drawTable();
				} catch (e) { }
				break;
		}
	}
}

function drawTable() {
	if (!tableData_ || !columnStyle_) {
		console.warn("Chưa có dữ liệu hoặc cấu hình cột!");
		return;
	}
	var tabledata = tableData_;
	var columnStyle = columnStyle_;
	let config = {
		height: 'calc(100% - 2px)',
		data: tabledata,
		layout: "fitColumns",
		columns: columnStyle,
	}
	if (tableConfig_ && Object.keys(tableConfig_).length) {
		config = Object.assign(config, tableConfig_);
	}

	$table = new Tabulator("#example-table", config);
	$table.replaceData(tabledata);
}