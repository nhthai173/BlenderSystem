function getAllCSSVariableNames(styleSheets = document.styleSheets){
   var cssVars = [];
   // loop each stylesheet
   for(var i = 0; i < styleSheets.length; i++){
      // loop stylesheet's cssRules
      try{ // try/catch used because 'hasOwnProperty' doesn't work
         for( var j = 0; j < styleSheets[i].cssRules.length; j++){
            try{
               // loop stylesheet's cssRules' style (property names)
               for(var k = 0; k < styleSheets[i].cssRules[j].style.length; k++){
                  let name = styleSheets[i].cssRules[j].style[k];
                  // test name for css variable signiture and uniqueness
                  if(name.startsWith('--') && cssVars.indexOf(name) == -1){
                     cssVars.push(name);
                  }
               }
            } catch (error) {}
         }
      } catch (error) {}
   }
   return cssVars;
}



function toColor(num) {
    num = Number(num);
    if (isNaN(num)) return '';
    num >>>= 0;
    var b = num & 0xFF,
        g = (num & 0xFF00) >>> 8,
        r = (num & 0xFF0000) >>> 16,
        a = ((num & 0xFF000000) >>> 24) / 255;
    return 'rgba(' + [r, g, b, a].join(',') + ')';
}


function toColorNumber(color) {
    if (typeof color === 'string') {
        if (color.startsWith('rgba(')) {
            color = color.replace(/rgba?\((\d+),\s*(\d+),\s*(\d+)(?:,\s*([\d.]+))?\)/, function (match, r, g, b, a) {
                return ((Number(a) || 1) * 255 << 24 | Number(r) << 16 | Number(g) << 8 | Number(b)) >>> 0;
            });
        } else if (color.startsWith('rgb(')) {
            color = color.replace(/rgb\((\d+),\s*(\d+),\s*(\d+)\)/, function (match, r, g, b) {
                return (255 << 24 | Number(r) << 16 | Number(g) << 8 | Number(b)) >>> 0;
            });
        } else if (color.startsWith('#')) {
            if (color.length === 4) {
                color = '#' + color[1] + color[1] + color[2] + color[2] + color[3] + color[3];
            }
            color = parseInt(color.slice(1), 16);
            if (color < 0x1000000) {
                color |= 0xFF000000; // Add alpha channel if missing
            }
            color = color >>> 0; // Ensure unsigned 32-bit integer
        } else {
            return NaN; // Invalid color format
        }
    }
    return Number(color);
}




function printPackageInfo() {
    console.log('====== Package Properties ======');
    const computed = window.getComputedStyle(document.querySelector(':root'));
    let properties = {};
    getAllCSSVariableNames().forEach(name => {
        let val = computed.getPropertyValue(name).trim();
        const key = name.replace(/-([a-z])/g, (g) => g[1].toUpperCase()).replace(/-/g, '');
        if (val.match(/\d+px/g)) {
            properties[key] = {
                "type": "number",
                "default": Number(val.replace('px', ''))
            }
        } else if (val.match(/\d+/g) && Number(val) == val) {
            properties[key] = {
                "type": "number",
                "default": Number(val)
            }
        } else {
            properties[key] = {
                "$ref": "#/control/types/Color",
                "default": toColorNumber(val)
            }
        }
    })
    // console.table(properties);
    console.log(properties)
    
    console.log('====== Properties default value ======');
    const defaultValues = {}
    for (const key in properties) {
        defaultValues[key] = properties[key].default;
    }
    console.log(defaultValues);
    
    console.log('===============================');
}
// printPackageInfo()