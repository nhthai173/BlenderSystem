/// <reference path="/Users/thainguyen/.vscode/extensions/undefined_publisher.wincc-custom-web-controls-0.0.1/typings/webcc.d.ts" />

let $container
let $root;


function changeColorVariable(varName, value) {
    if (!$root) return;
    if (!varName || !value) return;
    $root.style.setProperty('--' + varName, toColor(value));
}

function changelengthVariable(varName, value) {
    if (!$root) return;
    if (!varName || !value) return;
    console.log('--' + varName, value + 'px')
    $root.style.setProperty('--' + varName, value + 'px');
}

function changeNumberVariable(varName, value) {
    if (!$root) return;
    if (!varName || !value) return;
    $root.style.setProperty('--' + varName, value);
}

function changeStringVariable(varName, value) {
    return changeNumberVariable(varName, value);
}

function changeIcon(value) {
    if (!$container) return;
    let $icon = $container.querySelector('#icon');
    if ($icon) {
        $icon.innerHTML = value;
    }
}

function changeText(value = undefined, show = true) {
    if (!$container) return;
    let $text = $container.querySelector('#text');
    if ($text) {
        if (value !== undefined)
            $text.innerHTML = value;
        if (show) {
            $text.classList.remove('d-none');
            setTimeout(() => $text.classList.add('show'), 100)
        } else {
            $text.classList.remove('show');
            setTimeout(() => $text.classList.add('d-none'), 200);
        }
    }
}

function changeClass(clasName, addRemove = true) {
    if (!$container) return;
    if (!clasName) return;
    if (addRemove) {
        $container.classList.add(clasName);
    } else {
        $container.classList.remove(clasName);
    }
}

function setProperty(data) {
    if (!data || !data.key) return;
    const { key, value } = data;
    switch (key) {
        case 'IconHTML':
            changeIcon(value);
            break;
        case 'TextHTML':
            changeText(value);
            break;
        case 'TextPosition':
            changeClass('text-bottom', value == 'Bottom');
            changeClass('text-right', value == 'Right');
            break;
        case 'ButtonUI':
            changeClass('btn', value);
            break;
        case 'ButtonCircle':
            changeClass('btn-circle', value);
            break;
        case 'IsActive':
            changeClass('active', value);
            break;
        case 'ShowText':
            changeText(undefined, value);
            break;
        case 'IconSize':
            changelengthVariable('icon-size', value);
            break;
        case 'IconColor':
            changeColorVariable('icon-color', value);
            break;
        case 'TextSize':
            changelengthVariable('text-size', value);
            break;
        case 'TextSpace':
            changelengthVariable('text-space', value);
            break;
        case 'BtnActiveTextSize':
            changelengthVariable('btn-active-text-size', value);
            break;
        case 'BtnActiveTextWeight':
            changeNumberVariable('btn-active-text-weight', value);
            break;
        case 'BorderColor':
            changeColorVariable('border-color', value);
            break;
        case 'BorderWidth':
            changelengthVariable('border-width', value);
            break;
        case 'BtnBgColor':
            changeColorVariable('btn-bg-color', value);
            break;
        case 'BtnBoxShadowColor':
            changeColorVariable('btn-box-shadow-color', value);
            break;
        case 'BtnHoverBgColor':
            changeColorVariable('btn-hover-bg-color', value);
            break;
        case 'BtnHoverIconColor':
            changeColorVariable('btn-hover-icon-color', value);
            break;
        case 'BtnBorderRadius':
            changelengthVariable('btn-border-radius', value);
            break;
        case 'BtnPaddingX':
            changelengthVariable('btn-padding-x', value);
            break;
        case 'BtnPaddingY':
            changelengthVariable('btn-padding-y', value);
            break;
        case 'BtnActiveBgColor':
            changeColorVariable('btn-active-bg-color', value);
            break;
        case 'BtnActiveIconColor':
            changeColorVariable('btn-active-icon-color', value);
            break;
        case 'BtnActiveBoxShadowColor':
            changeColorVariable('btn-active-box-shadow-color', value);
            break;
        case 'BtnActiveBorderColor':
            changeColorVariable('btn-active-border-color', value);
            break;
        case 'BtnActiveBorderWidth':
            changelengthVariable('btn-active-border-width', value);
            break;
        case "BtnWidth":
            changelengthVariable('btn-width', value);
            break;
        case "BtnHeight":
            changelengthVariable('btn-height', value);
            break;
        case "BtnJustifyContent":
            changeStringVariable('btn-justify-content', value);
            break;
        default:
            console.warn(`[FAIcon] Unknown property: ${key}`);
            break;
    }
}


function getComputedStyleFromRoot(obj) {
    if (!$root) return {};
    const computed = window.getComputedStyle($root);
    const result = {};
    for (const key in obj) {
        const cssVar = '-' + key.replace(/([A-Z])/g, '-$1').toLowerCase();
        let val = computed.getPropertyValue(cssVar).trim();
        if (val.match(/\d+px/g)) {
            result[key] = Number(val.replace('px', ''));
        } else {
            result[key] = toColorNumber(val);
        }
    }
    return result;
}

// $container = document.getElementById('container');
// $root = document.querySelector(':root');
// changeIcon('<i class="fas fa-yin-yang"></i>');
// changeText('DM SP');
// changeClass('btn', true);
// setProperty({ key: 'TextPosition', value: 'Right' })
// setProperty({ key: 'TextSpace', value: 12 })
// setProperty({ key: 'BtnWidth', value: 200 })

// var lastState = false;
// setInterval(() => {
//     lastState = !lastState;
//     setProperty({ key: 'ShowText', value: lastState });
//     setProperty({ key: 'BtnWidth', value: lastState ? 150 : 50 });
// }, 2000);

WebCC.start(
    // callback function; occurs when the connection is done or failed. 
    // "result" is a boolean defining if the connection was successfull or not.
    function (result) {
        if (result) {
            $container = document.getElementById('container');
            $root = document.querySelector(':root');

            $container.addEventListener('click', function (e) {
                WebCC.Events.fire("LeftClick", e);
                console.log('[FAIcon] Click left mouse button');
            });
            $container.addEventListener('contextmenu', function (e) {
                e.preventDefault();
                WebCC.Events.fire("RightClick", e);
                console.log('[FAIcon] Click right mouse button');
            });
            $container.addEventListener('mousedown', function (e) {
                if (e.button === 0) { // left mouse button
                    WebCC.Events.fire("Press", e);
                    console.log('[FAIcon] Press');
                }
            });
            $container.addEventListener('mouseup', function (e) {
                if (e.button === 0) { // left mouse button
                    WebCC.Events.fire("Release", e);
                    console.log('[FAIcon] Release');
                }
            });

            // Set current values
            if (WebCC.Properties) {
                for (const key in WebCC.Properties) {
                    if (WebCC.Properties[key] !== undefined) {
                        setProperty({ key, value: WebCC.Properties[key] });
                    }
                }
            }
            // Subscribe for value changes
            WebCC.onPropertyChanged.subscribe(setProperty);
        } else {
            console.log('[FAIcon] Connection failed');
        }
    },
    // contract (see also manifest.json)
    {
        // Methods
        methods: {
            setActive: function (isActive) {
                WebCC.Properties.IsActive = isActive;
                setProperty({ key: 'IsActive', value: isActive });
            }
        },
        // Events
        events: [
            "LeftClick",
            "RightClick",
            "Press",
            "Release"
        ],
        // Properties
        properties: {
            IconHTML: "<i class=\"fas fa-yin-yang\"></i>",
            TextHTML: "",
            TextPosition: "Bottom",
            ButtonUI: false,
            ButtonCircle: false,
            IsActive: false,
            ShowText: true,
            "IconSize": 50,
            "IconColor": 4282664004,
            "TextSize": 18,
            "TextSpace": 6,
            "BorderColor": 4291611852,
            "BorderWidth": 0,
            "BtnBgColor": 4293980400,
            "BtnBoxShadowColor": 855638016,
            "BtnHoverBgColor": 4292927712,
            "BtnHoverIconColor": 4278190080,
            "BtnBorderRadius": 6,
            "BtnPaddingX": 20,
            "BtnPaddingY": 5,
            "BtnActiveBgColor": 4293456126,
            "BtnActiveIconColor": 4279855058,
            "BtnActiveTextSize": 18,
            "BtnActiveTextWeight": 550,
            "BtnActiveBoxShadowColor": 419430400,
            "BtnActiveBorderColor": 4279855058,
            "BtnActiveBorderWidth": 0,
            "BtnWidth": 150,
            "BtnHeight": 50,
            "BtnJustifyContent": "center"
        }
    },
    // placeholder to include additional Unified dependencies
    [],
    // connection timeout
    10000
);