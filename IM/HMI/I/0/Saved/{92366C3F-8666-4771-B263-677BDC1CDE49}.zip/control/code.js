/// <reference path="/Users/thainguyen/.vscode/extensions/undefined_publisher.wincc-custom-web-controls-0.0.1/typings/webcc.d.ts" />

const SampleData = [
    {
        text: "Item 1",
        value: "Item 1"
    },
    {
        text: "Item 2",
        value: "Item 2"
    },
    {
        text: "Item 3",
        value: "Item 3"
    },
    {
        text: "Item 4",
        value: "Item 4"
    }
]
let selectList = null


class SelectList {
    constructor(containerSelector, data = [], options = {}) {
        this.container = document.querySelector(containerSelector);
        this.searchInput = this.container.querySelector('.search input');
        this.clearIcon = this.container.querySelector('.clear-icon');
        this.listElement = this.container.querySelector('.list-content');
        this.searchContainer = this.container.querySelector('.search');

        this.data = []; // raw data
        this.filteredData = []; // show data
        this.searchData = []; // data for search
        this.selectedItems = new Set();

        this.allowMultiSelect = options.allowMultiSelect !== false; // default true
        this.allowSearch = options.allowSearch !== false; // default true
        this.selectAllText = options.selectAllText || 'Select All';

        this.updateData(data);
        this.init();
    }

    init() {
        this.setupUI();
        this.render();
        this.bindEvents();
    }

    setupUI() {
        // Hide search if not allowed
        if (!this.allowSearch) {
            this.searchContainer.style.display = 'none';
        } else {
            this.searchContainer.style.display = 'block';
        }
        if (!this.allowMultiSelect) {
            this.container.classList.add('single-select');
        } else {
            this.container.classList.remove('single-select');
        }
    }

    bindEvents() {
        // Search functionality - only if allowed
        if (this.allowSearch) {
            this.searchInput.addEventListener('input', (e) => {
                this.handleSearch(e.target.value);
            });

            // Clear search
            this.clearIcon.addEventListener('click', () => {
                this.clearSearch();
            });
        }

        // Item selection
        this.listElement.addEventListener('change', (e) => {
            if (e.target.type === 'checkbox') {
                this.handleItemSelection(e);
            }
        });
    }

    _toRawText(str) {
        if (!str) return ''
        str = str.replace(/à|á|ạ|ả|ã|â|ầ|ấ|ậ|ẩ|ẫ|ă|ằ|ắ|ặ|ẳ|ẵ/g, "a");
        str = str.replace(/è|é|ẹ|ẻ|ẽ|ê|ề|ế|ệ|ể|ễ/g, "e");
        str = str.replace(/ì|í|ị|ỉ|ĩ/g, "i");
        str = str.replace(/ò|ó|ọ|ỏ|õ|ô|ồ|ố|ộ|ổ|ỗ|ơ|ờ|ớ|ợ|ở|ỡ/g, "o");
        str = str.replace(/ù|ú|ụ|ủ|ũ|ư|ừ|ứ|ự|ử|ữ/g, "u");
        str = str.replace(/ỳ|ý|ỵ|ỷ|ỹ/g, "y");
        str = str.replace(/đ/g, "d");
        str = str.replace(/À|Á|Ạ|Ả|Ã|Â|Ầ|Ấ|Ậ|Ẩ|Ẫ|Ă|Ằ|Ắ|Ặ|Ẳ|Ẵ/g, "A");
        str = str.replace(/È|É|Ẹ|Ẻ|Ẽ|Ê|Ề|Ế|Ệ|Ể|Ễ/g, "E");
        str = str.replace(/Ì|Í|Ị|Ỉ|Ĩ/g, "I");
        str = str.replace(/Ò|Ó|Ọ|Ỏ|Õ|Ô|Ồ|Ố|Ộ|Ổ|Ỗ|Ơ|Ờ|Ớ|Ợ|Ở|Ỡ/g, "O");
        str = str.replace(/Ù|Ú|Ụ|Ủ|Ũ|Ư|Ừ|Ứ|Ự|Ử|Ữ/g, "U");
        str = str.replace(/Ỳ|Ý|Ỵ|Ỷ|Ỹ/g, "Y");
        str = str.replace(/Đ/g, "D");
        str = str.replace(/\u0300|\u0301|\u0303|\u0309|\u0323/g, ""); // ̀ ́ ̃ ̉ ̣  huyền, sắc, ngã, hỏi, nặng
        str = str.replace(/\u02C6|\u0306|\u031B/g, ""); // ˆ ̆ ̛  Â, Ê, Ă, Ơ, Ư
        str = str.toLowerCase()
        str = str.replace(/!|@|%|\^|\*|\(|\)|\+|\=|\<|\>|\?|\/|,|\.|\:|\;|\'|\"|\&|\#|\[|\]|~|\$|_|`|-|{|}|\||\\/g, "");
        str = str.trim();
        str = str.replace(/\s+/g, "");
        return str;
    }

    updateData(newData) {
        if (!Array.isArray(newData) || !newData.length) {
            console.error('Data must be an array');
            return;
        }
        if (!newData[0] || !newData[0].text || !newData[0].value) {
            console.error('Data items must have text and value properties');
            return;
        }
        this.data = newData;
        this.filteredData = [...newData];
        this.searchData = newData.map(item => {
            return {
                query: this._toRawText(item.text),
                text: item.text,
                value: item.value
            }
        });
        this.render();
    }

    setMultiSelect(allow) {
        this.allowMultiSelect = allow
        this.setupUI();
    }

    setSearch(allow) {
        this.allowSearch = allow;
        this.setupUI();
    }

    handleSearch(searchTerm) {
        searchTerm = this._toRawText(searchTerm);
        if (searchTerm === '') {
            this.clearSearch();
        } else {
            this.filteredData = this.searchData
                .filter(item => item.query.includes(searchTerm));
            this.clearIcon.classList.add('active');
            this.render(false);
        }
    }

    clearSearch() {
        this.searchInput.value = '';
        this.filteredData = [...this.data];
        this.clearIcon.classList.remove('active');
        this.render();
    }

    handleItemSelection(event) {
        const listItem = event.target.closest('.list-item');
        const itemValue = listItem.dataset.value;
        const itemText = listItem.querySelector('label').textContent.trim();

        if (itemValue === 'SELECT_ALL') {
            if (event.target.checked) {
                this.filteredData.forEach(item => {
                    this.selectedItems.add(item);
                });
            } else {
                this.filteredData.forEach(item => {
                    this.selectedItems.delete([...this.selectedItems].find(selected => selected.value === item.value));
                });
            }
            this.render();
            this.onSelectionChange();
            return;
        }

        if (this.allowMultiSelect) {
            // Multi-select behavior
            if (event.target.checked) {
                this.selectedItems.add({ value: itemValue, text: itemText });
                listItem.classList.add('selected');
            } else {
                this.selectedItems.delete([...this.selectedItems].find(item => item.value === itemValue));
                listItem.classList.remove('selected');
            }
        } else {
            // Single-select behavior
            if (event.target.checked) {
                // Clear all other selections
                this.selectedItems.clear();
                document.querySelectorAll('.list-item').forEach(item => {
                    item.classList.remove('selected');
                    item.querySelector('input[type="checkbox"]').checked = false;
                });

                // Select current item
                this.selectedItems.add({ value: itemValue, text: itemText });
                listItem.classList.add('selected');
                event.target.checked = true;
            } else {
                this.selectedItems.delete([...this.selectedItems].find(item => item.value === itemValue));
                listItem.classList.remove('selected');
            }
        }

        this.onSelectionChange();
    }

    render(showSelectAll = true) {
        this.listElement.innerHTML = '';

        if (this.allowMultiSelect) {
            const allSelected = this.filteredData.length > 0 && this.filteredData.every(item =>
                [...this.selectedItems].some(selected => selected.value === item.value)
            );
            if (showSelectAll) {
                const selectAllItem = document.createElement('li');
                selectAllItem.dataset.value = 'SELECT_ALL';
                selectAllItem.className = 'list-item select-all-item';
                selectAllItem.innerHTML = `
                    <label class="checkbox">${this.selectAllText}
                        <input type="checkbox" ${allSelected ? 'checked' : ''}>
                        <span class="checkmark"></span>
                    </label>
                `;
                this.listElement.appendChild(selectAllItem);
            }
        }

        this.filteredData.forEach((item, index) => {
            const listItem = document.createElement('li');
            listItem.className = 'list-item';
            listItem.dataset.value = item.value;

            const isSelected = [...this.selectedItems].some(selected => selected.value == item.value);

            // Use radio button for single select, checkbox for multi-select
            const inputType = this.allowMultiSelect ? 'checkbox' : 'checkbox';

            listItem.innerHTML = `
                <label class="checkbox">${item.text}
                    <input type="${inputType}" ${isSelected ? 'checked' : ''}>
                    <span class="checkmark"></span>
                </label>
            `;

            if (isSelected) {
                listItem.classList.add('selected');
            }

            this.listElement.appendChild(listItem);
        });
    }

    // Public methods
    getSelectedItems() {
        return [...this.selectedItems];
    }

    setSelectedItems(items) {
        this.selectedItems = new Set(items);
        this.render();
    }

    addItem(item) {
        this.data.push(item);
        this.filteredData = [...this.data];
        this.render();
    }

    removeItem(item) {
        const index = this.data.indexOf(item);
        if (index > -1) {
            this.data.splice(index, 1);
            this.filteredData = [...this.data];
            // Remove from selected items if exists
            this.selectedItems.delete([...this.selectedItems].find(selected => selected.text === item));
            this.render();
        }
    }

    clearSelection() {
        this.selectedItems.clear();
        this.render();
    }

    selectAll() {
        if (!this.allowMultiSelect) {
            console.warn('selectAll() is not available in single-select mode');
            return;
        }

        this.filteredData.forEach((item, index) => {
            this.selectedItems.add(item);
        });
        this.render();
    }

    // Event callback - override this method
    onSelectionChange() {
        const selectedItems = this.getSelectedItems();
        console.table(selectedItems);
        // Notify WebCC about the selection change
        WebCC.Events.fire('onSelectionChange', JSON.stringify(selectedItems));
    }
}


// DEBUG
// selectList = new SelectList('#list-content', SampleData, {
//     allowMultiSelect: true,
//     allowSearch: true,
//     selectAllText: "Select All"
// });
// printPackageInfo()


////////////////////////////////////////////
// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)

WebCC.start(
    // callback function; occurs when the connection is done or failed. 
    // "result" is a boolean defining if the connection was successfull or not.
    function (result) {
        if (result) {
            if (WebCC.isDesignMode) {
                // Sample data
                try {
                    if (!WebCC.Properties.DataJSONString) {
                        WebCC.Properties.DataJSONString = JSON.stringify(SampleData);
                    }
                } catch (e) { }
            }

            // init
            let data = []
            try {
                data = JSON.parse(WebCC.Properties.DataJSONString);
            } catch (e) { }
            selectList = new SelectList('#list-content', data, {
                allowMultiSelect: WebCC.Properties.SelectListConfig.AllowMultiSelect,
                allowSearch: WebCC.Properties.SelectListConfig.AllowSearch,
                selectAllText: WebCC.Properties.SelectAllText
            });
            
            // Get css properties
            getCssProperties();

            // Set current values when CWC shows up
            for (const key in WebCC.Properties) {
                setProperty({ key, value: WebCC.Properties[key] });
            }

            // Subscribe for future value changes
            WebCC.onPropertyChanged.subscribe(setProperty);
        }
        else {
            console.log('connection failed');
        }
    },
    // contract (same as manifest.json)
    {
        // Methods
        methods: {},
        // Events
        events: ["onSelectionChange"],
        // Properties
        properties: {
            SelectListConfig: {
                AllowSearch: true,
                AllowMultiSelect: true
            },
            SelectAllText: "Select All",
            DataJSONString: "",
            "FontSize": 18,
            "BgColor": 4293651952,
            "AlterBgColor": 4291874253,
            "TextColor": 4287006342,
            "AlterTextColor": 4291940822,
            "CheckColor": 4290369002
        }
    },
    // placeholder to include additional Unified dependencies (not used in this example)
    [],
    // connection timeout
    10000
);

function setProperty(data) {
    const { key, value } = data;
    if (Object.keys(CssProperties).includes(key)) {
        try {
            const prop = CssProperties[key];
            switch (prop.type) {
                case "color":
                    setRootProperty(key, toColor(value));
                    break;
                case "size":
                    setRootProperty(key, value + 'px');
                    break;
                case "number": case "raw":
                    setRootProperty(key, value);
                    break;
            }
        } catch (e) { }
    } else {
        switch (key) {
            case "DataJSONString":
                let data = [];
                try {
                    data = JSON.parse(value);
                } catch (e) { }
                selectList.updateData(data);
                break;
            case "SelectAllText":
                selectList.selectAllText = value;
                selectList.render();
                break;
            case "SelectListConfig":
                if (value.AllowSearch !== undefined) {
                    selectList.setSearch(value.AllowSearch);
                }
                if (value.AllowMultiSelect !== undefined) {
                    selectList.setMultiSelect(value.AllowMultiSelect);
                }
                selectList.render();
                break;
        }
    }
}