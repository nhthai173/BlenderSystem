/// <reference path="/Users/thainguyen/.vscode/extensions/undefined_publisher.wincc-custom-web-controls-0.0.1/typings/webcc.d.ts" />


/* ================================================= */
/* ================ Calendar Select ================ */
/* ================================================= */

class DateLimitClass {
    constructor(minDate = null, maxDate = null) {
        this.minDate = DateLimitClass.parseDate(minDate)
        this.maxDate = DateLimitClass.parseDate(maxDate)
        this.minYear = 0
        this.maxYear = 3000
        this.availableMonths = {}
        this._calc()
    }

    _calc() {
        if (this.minDate && this.minDate instanceof Date) {
            let y = this.minDate.getFullYear()
            this.minYear = y
            if (!this.availableMonths[y]) {
                this.availableMonths[y] = { min: this.minDate.getMonth(), max: 11 }
            } else {
                this.availableMonths[y].min = this.minDate.getMonth()
            }
        }
        if (this.maxDate && this.maxDate instanceof Date) {
            let y = this.maxDate.getFullYear()
            this.maxYear = y
            if (!this.availableMonths[y]) {
                this.availableMonths[y] = { min: 0, max: this.maxDate.getMonth() }
            } else {
                this.availableMonths[y].max = this.maxDate.getMonth()
            }
        }
    }

    /**
     * Get available months for a given year
     * @param {number} year 
     * @returns {number[]}
     */
    getMonths(year) {
        let months = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11]
        const obj = this.availableMonths[year];
        if (!year || !obj || !obj.min || !obj.max) return months;

        months = [];
        for (let m = obj.min; m <= obj.max; ++m) {
            months.push(m);
        }
        return months;
    }

    /**
     * Get available years within the specified range
     * @param {number} min year min
     * @param {number} max year max
     * @returns {number[]} Array of years
     */
    getYears(min = null, max = null) {
        min = isNaN(Number(min)) ? this.minYear : Number(min);
        max = isNaN(Number(max)) ? this.maxYear : Number(max);
        let minY = Math.max(this.minYear, min);
        let maxY = Math.min(this.maxYear, max);
        let years = [];
        for (let y = minY; y <= maxY; ++y) {
            years.push(y);
        }
        return years;
    }

    /**
     * Check if a date is valid within the min and max date range
     * @param {*} date 
     */
    isValidDate(date) {
        // timestamp
        if (!isNaN(Number(date))) {
            date = new Date(Number(date));
        } else if (date instanceof String || typeof date === 'string') {
            date = DateLimitClass.parseDate(date);
        }
        if (!date || !(date instanceof Date) || isNaN(date.getTime())) {
            return false;
        }
        if (this.minDate && date.getTime() < this.minDate.getTime()) {
            return false;
        }
        if (this.maxDate && date.getTime() > this.maxDate.getTime()) {
            return false;
        }
        return true;
    }

    setMinDate(date) {
        this.minDate = DateLimitClass.parseDate(date)
        this._calc()
    }
    setMaxDate(date) {
        this.maxDate = DateLimitClass.parseDate(date)
        this._calc()
    }
    setDateRange(minDate, maxDate) {
        this.setMinDate(minDate)
        this.setMaxDate(maxDate)
    }

    static parseDate(date = '', defaultDate = null) {
        if (!date) return defaultDate;
        if (date instanceof Date) return date;

        if (date.toLowerCase() == 'today') {
            return new Date();
        }
        // match dd/mm/yyyy format
        else if (date.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)) {
            const parts = date.split('/');
            const d = Number(parts[0]);
            const m = Number(parts[1]) - 1; // month is 0-indexed
            const y = Number(parts[2]);
            if (isNaN(d) || isNaN(m) || isNaN(y)) return null;
            return new Date(y, m, d);
        }
        // match yyyy-mm-dd format
        else if (date.match(/^\d{4}-\d{2}-\d{2}$/)) {
            const parts = date.split('-');
            const y = Number(parts[0]);
            const m = Number(parts[1]) - 1; // month is 0-indexed
            const d = Number(parts[2]);
            if (isNaN(d) || isNaN(m) || isNaN(y)) return null;
            return new Date(y, m, d);
        }
        return defaultDate;
    }
}

let $container = null;
let $nextBtn = null;
let $prevBtn = null;
let $clearBtn = null;
let $todayBtn = null;
let $doneBtn = null;
let $monthYearLabel = null;
let $selectYear = null;
let $selectYearDropdown = null;
let $selectMonth = null;
let $selectMonthDropdown = null;
let $dateGrid = null;

let SelectedDate = null;
let CurrentMonth = null;
let DateLimit = new DateLimitClass();
let TempYear = null;
let TempMonth = null;

let onChangeFn = null;


function init({ defaultDate, minDate, maxDate, onChange } = {}) {
    SelectedDate = DateLimitClass.parseDate(defaultDate, new Date());
    CurrentMonth = new Date(SelectedDate)
    DateLimit.setMinDate(minDate);
    DateLimit.setMaxDate(maxDate);
    onChangeFn = onChange || null;

    $container = document.querySelector('.select-date-calendar');
    if (!$container) {
        console.error('Container not found');
        return;
    }

    $nextBtn = $container.querySelector('.calendar-nav.date-select.next');
    $prevBtn = $container.querySelector('.calendar-nav.date-select.prev');
    $doneBtn = $container.querySelector('.calendar-nav.month-select');
    $clearBtn = $container.querySelector('.calendar-nav.button-clear');
    $todayBtn = $container.querySelector('.calendar-nav.button-today');
    $monthYearLabel = $container.querySelector('.calendar-month-year');
    $selectYear = $container.querySelector('#select-year');
    $selectYearDropdown = $container.querySelector('.calendar-month-select #select-year + .select-dropdown');
    $selectMonth = $container.querySelector('#select-month');
    $selectMonthDropdown = $container.querySelector('.calendar-month-select #select-month + .select-dropdown');
    $dateGrid = $container.querySelector('.calendar-dates-grid');

    // Event listeners
    // select date event
    $prevBtn.addEventListener('click', () => changeMonth(-1));
    $nextBtn.addEventListener('click', () => changeMonth(1));
    $doneBtn.addEventListener('click', (e) => changeView('select-date'));
    $todayBtn.addEventListener('click', () => selectDate(new Date()));
    $clearBtn.addEventListener('click', () => selectDate(null));
    $monthYearLabel.addEventListener('click', () => changeView('select-month'));
    $dateGrid.addEventListener('click', e => {
        if (!e.target.classList.contains('calendar-day')) return
        const timestamp = e.target.dataset.timestamp;
        if (!timestamp) return;
        selectDate(new Date(parseInt(timestamp)));
    })

    // select month event
    $selectYear.addEventListener('click', (e) => {
        console.log('select year clicked', e);
        $container.querySelectorAll('.select').forEach(el => {
            if (el !== e.target)
                el.classList.remove('show-menu');
        });
        e.target.classList.toggle('show-menu');
        // scroll to selected year
        const liHeight = getComputedStyle($selectYearDropdown.querySelector('li')).getPropertyValue('height');
        if (!liHeight) return;
        const list = [];
        $selectYearDropdown.querySelectorAll('li').forEach(li => list.push(li.dataset.value));
        let selectedIndex = list.indexOf(String(TempYear));
        const h = Number(liHeight.replace('px', ''));
        $selectYearDropdown.scrollTop = Math.max(0, selectedIndex * h - 2 * h);
    });
    $selectMonth.addEventListener('click', (e) => {
        console.log('select month clicked', e);
        $container.querySelectorAll('.select').forEach(el => {
            if (el !== e.target)
                el.classList.remove('show-menu');
        });
        e.target.classList.toggle('show-menu');
        // scroll to selected month
        const liHeight = getComputedStyle($selectMonthDropdown.querySelector('li')).getPropertyValue('height');
        if (!liHeight) return;
        const list = [];
        $selectMonthDropdown.querySelectorAll('li').forEach(li => list.push(li.dataset.value));
        let selectedIndex = list.indexOf(String(TempMonth));
        const h = Number(liHeight.replace('px', ''));
        $selectMonthDropdown.scrollTop = Math.max(0, selectedIndex * h - 2 * h);
    });
    $container.addEventListener('click', (e) => {
        console.log('root container clicked', e);
        if (!e.target.closest('.select')) {
            $container.querySelectorAll('.select').forEach(el => {
                el.classList.remove('show-menu');
            });
        }
    });
    $selectYearDropdown.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const selectedYear = parseInt(e.target.dataset.value);
            if (isNaN(selectedYear)) return;
            TempYear = selectedYear;
            $selectYear.textContent = selectedYear;
            $selectYearDropdown.querySelectorAll('li').forEach(li => li.classList.remove('selected'));
            e.target.classList.add('selected');
            $selectYear.classList.remove('show-menu');
            _renderMonthDropdown();
        }
    });
    $selectMonthDropdown.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const selectedMonth = parseInt(e.target.dataset.value);
            if (isNaN(selectedMonth)) return;
            TempMonth = selectedMonth;
            $selectMonth.textContent = String(selectedMonth + 1).padStart(2, '0');
            $selectMonthDropdown.querySelectorAll('li').forEach(li => li.classList.remove('selected'));
            e.target.classList.add('selected');
            $selectMonth.classList.remove('show-menu');
        }
    });
    // scroll event
    $selectYearDropdown.addEventListener('scroll', (e) => {
        const el = e.target;
        const lastScrollTop = el.dataset.lastScrollTop || 0;
        const liHeight = getComputedStyle(el.querySelector('li')).getPropertyValue('height');
        const first = el.querySelector('li:first-child');
        const last = el.querySelector('li:last-child');
        if (!first || !last) return;
        const firstYear = parseInt(first.dataset.value);
        const lastYear = parseInt(last.dataset.value);
        const h = Number(liHeight.replace('px', ''));
        if (el.scrollTop < lastScrollTop && el.scrollTop < 50) {
            const { min, max } = _renderYearDropdown(firstYear - 10, lastYear);
            $selectYearDropdown.scrollTop = Math.max(0, (firstYear - min) * h - 2 * h);
        } else if (el.scrollTop > lastScrollTop && el.scrollHeight - el.scrollTop - el.clientHeight < 50) {
            const { min, max } = _renderYearDropdown(firstYear, lastYear + 10);
            $selectYearDropdown.scrollTop = Math.max(0, (lastYear - firstYear) * h - 2 * h);
        }
        el.dataset.lastScrollTop = el.scrollTop;
    });

    _renderYearDropdown();
    _renderMonthDropdown();

    render();
}


/**
 * 
 * @param {number} monthOffset 
 * @returns {{numAvailableDays: number, days: {date: Date, class: string, text: string, timestamp: number}[]}} Object containing the month view data
 */
function _getMonthView(monthOffset = 0) {
    const month = new Date(CurrentMonth.getFullYear(), CurrentMonth.getMonth() + monthOffset, 1);
    let firstDay, lastDay, lastDate, numOfPrevDays, numOfNextDays, totalDays, dayCnt = 0, numAvailableDays = 0;
    const res = { numAvailableDays: 0, days: [] };
    firstDay = month.getDay();
    month.setMonth(month.getMonth() + 1);
    month.setDate(0);
    lastDay = month.getDay();
    lastDate = month.getDate();
    numOfPrevDays = (firstDay + 6) % 7;
    numOfNextDays = (7 - lastDay - 1) % 7;
    totalDays = numOfPrevDays + lastDate + numOfNextDays;
    month.setDate(1 - numOfPrevDays); // Set to the last days of the previous month
    while (true) {
        let classList = ['calendar-day'];
        const day = new Date(month);
        if (day.getMonth() == CurrentMonth.getMonth() && day.getFullYear() == CurrentMonth.getFullYear()) {
            classList.push('current-month');
        }
        if (!DateLimit.isValidDate(day)) {
            classList.push('disabled');
        }
        if (SelectedDate && day.toLocaleDateString() == SelectedDate.toLocaleDateString()) {
            classList.push('selected');
        }
        if (classList.includes('current-month') && !classList.includes('disabled')) {
            numAvailableDays++;
        }
        res.days.push({
            date: day,
            class: classList.join(' '),
            text: day.getDate(),
            timestamp: day.getTime()
        });
        // Move to the next day
        month.setDate(month.getDate() + 1);
        dayCnt++;
        if (dayCnt >= totalDays) break;
    }
    res.numAvailableDays = numAvailableDays;
    return res;
}

function _renderYearDropdown(min, max) {
    min = min || TempYear - 10
    max = max || TempYear + 10;
    const years = DateLimit.getYears(min, max);

    $selectYear.classList.remove('disabled');
    $selectYearDropdown.innerHTML = '';
    years.forEach(y => {
        const li = document.createElement('li');
        li.className = 'select-dropdown-item';
        li.textContent = y;
        li.dataset.value = y;
        if (y === TempYear) {
            li.classList.add('selected');
        }
        $selectYearDropdown.appendChild(li);
    })
    if (years.length === 1) {
        $selectYear.classList.add('disabled');
    }
    return {
        min: years[0],
        max: years[years.length - 1]
    }
}

function _renderMonthDropdown() {
    const months = DateLimit.getMonths(TempYear);
    $selectMonthDropdown.innerHTML = '';
    $selectMonth.classList.remove('disabled');
    months.forEach(m => {
        const li = document.createElement('li');
        li.className = 'select-dropdown-item';
        li.textContent = String(m + 1).padStart(2, '0');
        li.dataset.value = m;
        if (m === TempMonth) {
            li.classList.add('selected');
        }
        $selectMonthDropdown.appendChild(li);
    });
    if (months.length === 0) {
        $selectMonth.classList.add('disabled');
    }
    if (!$selectMonthDropdown.querySelector('.selected')) {
        const firstLi = $selectMonthDropdown.querySelector('li');
        firstLi.classList.add('selected');
        TempMonth = parseInt(firstLi.dataset.value);
        $selectMonth.textContent = String(TempMonth + 1).padStart(2, '0');
    }
}


/**
 * Change between date and month view
 * @param {string} view 
 */
function changeView(view) {
    if (view == 'select-date') {
        CurrentMonth.setFullYear(TempYear, TempMonth);
        $container.classList.remove('select-month');
        $container.classList.add('select-date');
        render();
    }
    else if (view == 'select-month') {
        TempYear = CurrentMonth.getFullYear();
        TempMonth = CurrentMonth.getMonth();
        _renderYearDropdown();
        _renderMonthDropdown();
        $selectYear.textContent = TempYear;
        $selectMonth.textContent = String(TempMonth + 1).padStart(2, '0');
        $container.classList.remove('select-date');
        $container.classList.add('select-month');
    }
}

/**
 * Render the calendar view
 */
function render() {
    // Header
    $monthYearLabel.textContent = `${String(CurrentMonth.getMonth() + 1).padStart(2, '0')}/${CurrentMonth.getFullYear()}`;

    // Check available prev and next buttons
    const prevView = _getMonthView(-1);
    const nextView = _getMonthView(1);
    prevView.numAvailableDays === 0 ? ($prevBtn.classList.add('disabled')) : ($prevBtn.classList.remove('disabled'));
    nextView.numAvailableDays === 0 ? ($nextBtn.classList.add('disabled')) : ($nextBtn.classList.remove('disabled'));

    // Render day
    $dateGrid.innerHTML = '';
    const monthView = _getMonthView();
    monthView.days.forEach(day => {
        const dayElement = document.createElement('div');
        dayElement.className = day.class;
        dayElement.textContent = day.text;
        dayElement.dataset.timestamp = day.timestamp;
        $dateGrid.appendChild(dayElement);
    });
}

/**
 * Change month in date view
 * @param {number} offset 
 */
function changeMonth(offset) {
    CurrentMonth.setMonth(CurrentMonth.getMonth() + offset);
    render();
}

/**
 * Set the selected date and render the calendar
 * @param {Date|number} dateObj 
 */
function selectDate(dateObj) {
    // clear date
    if (!dateObj) {
        SelectedDate = null;
        CurrentMonth = new Date();
        render();
        if (onChangeFn) {
            onChangeFn(null);
        }
        return;
    }
    // set date
    SelectedDate = new Date(dateObj);
    CurrentMonth = new Date(SelectedDate.getFullYear(), SelectedDate.getMonth(), 1);
    render();
    if (onChangeFn) {
        onChangeFn(SelectedDate);
    }
}




/* ================================================= */
/* ===================== Main ====================== */
/* ================================================= */


var objectVar = null

function onSelectedChange(selectedDate) {
    console.log('Selected date:', selectedDate);
    // Notify WebCC about the selection change
    if (selectedDate) {
        WebCC.Events.fire('onSelectionChange', selectedDate.toISOString());
    } else {
        WebCC.Events.fire('onSelectionChange', 'null');
    }
}



// init({
//     defaultDate: 'today',
//     minDate: '',
//     maxDate: '',
//     onChange: onSelectedChange
// });
// printPackageInfo()



////////////////////////////////////////////
// Initialize the custom control (without a successful initialization, the CWC will remain empty. Make sure to include the webcc.min.js script!)

WebCC.start(
    // callback function; occurs when the connection is done or failed. 
    // "result" is a boolean defining if the connection was successfull or not.
    function (result) {
        if (result) {
            // if (WebCC.isDesignMode) { }

            // init select list or calendar
            init({
                defaultDate: WebCC.Properties.DefaultDate || 'today',
                minDate: WebCC.Properties.MinDate || '',
                maxDate: WebCC.Properties.MaxDate || '',
                onChange: onSelectedChange
            });

            // Get css properties
            getCssProperties();

            // Set current values when CWC shows up
            for (const key in WebCC.Properties) {
                setProperty({ key, value: WebCC.Properties[key] });
            }

            // Subscribe for future value changes
            WebCC.onPropertyChanged.subscribe(setProperty);
        }
        else {
            console.log('connection failed');
        }
    },
    // contract (same as manifest.json)
    {
        // Methods
        methods: {
            defaultView: () => {
                if (objectVar) {
                    objectVar.defaultView();
                }
            }
        },
        // Events
        events: ["onSelectionChange"],
        // Properties
        properties: {
            DefaultDate: "today",
            MinDate: "",
            MaxDate: "",
            "FontSize": 18,
            "BgColor": 4293651952,
            "AlterBgColor": 4291874253,
            "TextColor": 4287006342,
            "AlterTextColor": 4291940822,
            "CheckColor": 4292664540,
            "ActiveColor": 4279858898,
            "BodyPadding": 0,
            "ContentPadding": 10,
            "BorderRadius": 20
        }
    },
    // placeholder to include additional Unified dependencies (not used in this example)
    [],
    // connection timeout
    10000
);


function setProperty(data) {
    const { key, value } = data;
    if (Object.keys(CssProperties).includes(key)) {
        try {
            const prop = CssProperties[key];
            switch (prop.type) {
                case "color":
                    setRootProperty(key, toColor(value));
                    break;
                case "size":
                    setRootProperty(key, value + 'px');
                    break;
                case "number": case "raw":
                    setRootProperty(key, value);
                    break;
            }
        } catch (e) { }
    } else {
        if (WebCC.Properties[key] === undefined) return;
        if (!objectVar) return;
        switch (key) {
            case "DefaultDate":
                selectDate(value);
                break;
            case "MinDate":
                DateLimit.setMinDate(value);
                render();
                break;
            case "MaxDate":
                DateLimit.setMaxDate(value);
                render();
                break;
        }
    }
}